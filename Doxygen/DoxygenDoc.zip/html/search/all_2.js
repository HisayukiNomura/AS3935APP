var searchData=
[
  ['buffer_0',['buffer',['../class_ring_buffer_t.html#a184a5c2b975735187ef568409595550b',1,'RingBufferT']]]
];
