var searchData=
[
  ['edtcursor_0',['edtCursor',['../class_g_u_i_edit_box.html#a2f17414d0d68a528d038fd2f0cd4a40d',1,'GUIEditBox::edtCursor'],['../class_settings.html#a7379ea53b7bf25ef0d346f2bdc550d17',1,'Settings::edtCursor']]],
  ['edtx_1',['edtX',['../class_g_u_i_edit_box.html#a4425c191a828a3f37dc61b6d7c55cd7a',1,'GUIEditBox::edtX'],['../class_settings.html#a8212ce3d335329480b63635cf377ca29',1,'Settings::edtX']]],
  ['edty_2',['edtY',['../class_g_u_i_edit_box.html#a764340ddeaf92a7ef3e511ab9aec38d3',1,'GUIEditBox::edtY'],['../class_settings.html#af506adb3aaef7c8e71cdd01430d0af47',1,'Settings::edtY']]]
];
