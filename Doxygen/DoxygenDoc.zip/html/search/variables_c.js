var searchData=
[
  ['rear_0',['rear',['../class_ring_buffer_t.html#a9b1852147cdf42ce77b6d0822260da6f',1,'RingBufferT']]]
];
