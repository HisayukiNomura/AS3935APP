var searchData=
[
  ['lastdata_0',['lastData',['../class_ring_buffer_t.html#ab96125b42968d8f600f6037337807c67',1,'RingBufferT']]],
  ['lasterr_5fconnect_1',['lastErr_Connect',['../class_inet_action.html#a7657740c04435be2fd4355e77b38c71d',1,'InetAction']]],
  ['lasterr_5fsntp_2',['lastErr_Sntp',['../class_inet_action.html#a0bd347c97e9cca961e95c64769017319',1,'InetAction']]]
];
