var searchData=
[
  ['wifiicon_5fng_0',['wifiIcon_NG',['../pict_data_8h.html#a8f1a2cf14e333e12c007a0e9d9fdea36',1,'pictData.h']]],
  ['wifiicon_5fok_1',['wifiIcon_OK',['../pict_data_8h.html#a5e2fc65051ab71e680a4beef6929bcb7',1,'pictData.h']]]
];
