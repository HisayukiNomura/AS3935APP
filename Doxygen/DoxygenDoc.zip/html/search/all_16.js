var searchData=
[
  ['yrange_0',['YRANGE',['../_settings_8cpp.html#a112afdcee299caf7e37ee7ec7cb51951',1,'Settings.cpp']]]
];
