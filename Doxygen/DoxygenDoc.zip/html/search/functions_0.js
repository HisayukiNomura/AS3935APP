var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../_settings_8h.html#a189a2a16c0eacbb8ca8e2131d3d0c997',1,'Settings.h']]]
];
