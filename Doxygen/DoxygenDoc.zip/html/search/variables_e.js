var searchData=
[
  ['value_0',['value',['../class_settings.html#adcbc8dc6576f6fc3fbe9b3445f895fdb',1,'Settings']]]
];
