var searchData=
[
  ['ntp_5ft_5f_0',['NTP_T_',['../struct_n_t_p___t__.html',1,'']]]
];
