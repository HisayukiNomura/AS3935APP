var indexSectionsWithContent =
{
  0: "_abcdefghiklmnprstuvwxy~シソタネハメラ使初周回数文機特監設雷",
  1: "adfginrst",
  2: "a",
  3: "acdfgilprstv",
  4: "_acdefghilmnprstvw~",
  5: "abcefgiklmnprsvw",
  6: "din",
  7: "adeikm",
  8: "acdikmnprstuvx",
  9: "_acdefhilmnprstuwy",
  10: "ap雷"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "名前空間",
  3: "ファイル",
  4: "関数",
  5: "変数",
  6: "型定義",
  7: "列挙型",
  8: "列挙値",
  9: "マクロ定義",
  10: "ページ"
};

