var searchData=
[
  ['ntp_5ffailed_5fhandler_0',['ntp_failed_handler',['../_inet_action_8cpp.html#a46ab4b92a0280d2038d30be8f54a2916',1,'InetAction.cpp']]],
  ['ntp_5frecv_1',['ntp_recv',['../_inet_action_8cpp.html#ae0a2ceddddf105e1bc0843b8900b38ac',1,'InetAction.cpp']]]
];
