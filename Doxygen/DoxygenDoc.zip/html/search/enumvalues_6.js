var searchData=
[
  ['none_0',['NONE',['../_a_s3935_8h.html#a35733ea8bb2ddf7beeec5e770bed4616ac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'AS3935.h']]]
];
