var searchData=
[
  ['dreq_5fnum_5frp2040_0',['dreq_num_rp2040',['../dreq_8h.html#a864c3313155ab20116b62a64bf78df6d',1,'dreq.h']]]
];
