var searchData=
[
  ['sio_5firq_5fproc0_0',['SIO_IRQ_PROC0',['../intctrl_8h.html#af4bf6b287c1a8445fce49ccaa711b3c3a841acbddc6961252827d7645277452ec',1,'intctrl.h']]],
  ['sio_5firq_5fproc1_1',['SIO_IRQ_PROC1',['../intctrl_8h.html#af4bf6b287c1a8445fce49ccaa711b3c3ae00819201c60acdf59448df5a08c11b5',1,'intctrl.h']]],
  ['spi0_5firq_2',['SPI0_IRQ',['../intctrl_8h.html#af4bf6b287c1a8445fce49ccaa711b3c3a10b2c78ee63a060db5d9f30b8f1daf8a',1,'intctrl.h']]],
  ['spi1_5firq_3',['SPI1_IRQ',['../intctrl_8h.html#af4bf6b287c1a8445fce49ccaa711b3c3a60f73b071388a649cac65d2026607540',1,'intctrl.h']]],
  ['statclear_4',['STATCLEAR',['../_a_s3935_8h.html#a35733ea8bb2ddf7beeec5e770bed4616a57d3316e7827a89dea85f9a63ce0e7fe',1,'AS3935.h']]]
];
