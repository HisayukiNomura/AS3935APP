var searchData=
[
  ['load_0',['load',['../class_settings.html#a06d1d58938c8fdc7a577e52f9ffda29d',1,'Settings']]]
];
