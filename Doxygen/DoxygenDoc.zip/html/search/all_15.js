var searchData=
[
  ['xip_5firq_0',['XIP_IRQ',['../intctrl_8h.html#af4bf6b287c1a8445fce49ccaa711b3c3a76f444f019edf6356c9e64a1c2714b30',1,'intctrl.h']]]
];
