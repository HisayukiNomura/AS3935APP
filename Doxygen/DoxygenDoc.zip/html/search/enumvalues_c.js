var searchData=
[
  ['valid_0',['VALID',['../_a_s3935_8h.html#a35733ea8bb2ddf7beeec5e770bed4616acf0713491d9b887eaccfd80c18abca47',1,'AS3935.h']]]
];
