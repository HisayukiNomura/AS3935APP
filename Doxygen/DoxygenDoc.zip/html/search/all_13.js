var searchData=
[
  ['valid_0',['VALID',['../_a_s3935_8h.html#a35733ea8bb2ddf7beeec5e770bed4616acf0713491d9b887eaccfd80c18abca47',1,'AS3935.h']]],
  ['validatesignal_1',['validateSignal',['../class_a_s3935.html#ab30374bc87e8a08909dfd4f8f67885b0',1,'AS3935']]],
  ['value_2',['value',['../class_settings.html#adcbc8dc6576f6fc3fbe9b3445f895fdb',1,'Settings']]],
  ['version_2eh_3',['version.h',['../version_8h.html',1,'']]]
];
